import telebot
import os
from vision import get_image_from_camera
from vision import count_faces

bot = telebot.TeleBot("1918344985:AAFnF5zliY0ULGMLxXE0X4WxXb69aJzDzc8")
image_path = get_image_from_camera()
c = count_faces(image_path)

if c > 0:
    bot.send_message(
        240940120,
        f"{os.getlogin()} на вашем этаже обнаружен инопланетянин",
    )

    bot.send_photo(240940120, open(image_path, "rb"))
