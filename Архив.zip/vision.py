from typing import Any, Tuple
import cv2
import requests
import time
import concurrent.futures


def get_image_from_camera(name="./test.jpg") -> None:
    r = requests.get(
        "http://v.intercom.pik-comfort.ru:34568/snapshot/OZtFwPM-l7co4Ztu7lx-pAdeuez5SaXkrjWIvqZ_lxasM2rkIg7axhUUiAqrTCQ0n7VQL9cIzggxST2wNhO_6CqC20brEzrSAFahtw3gD2Y"
    )
    print(type(r.content))
    with open(name, "wb") as f:
        f.write(r.content)

    return name


def viewImage(image, name_of_window):
    cv2.namedWindow(name_of_window, cv2.WINDOW_NORMAL)
    cv2.imshow(name_of_window, image)
    cv2.waitKey(1000)
    cv2.destroyAllWindows()


def count_faces(image_path: str) -> int:
    # image_path = "./test.jpg"
    face_cascade = cv2.CascadeClassifier("haarcascade_frontalface_default.xml")
    image = cv2.imread(image_path)
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(
        gray, scaleFactor=1.1, minNeighbors=5, minSize=(10, 10)
    )
    print(f"Найдено {len(faces)} лиц")

    # Рисуем квадраты вокруг лиц
    for (x, y, w, h) in faces:
        cv2.rectangle(image, (x, y), (x + w, y + h), (255, 255, 0), 2)
    # viewImage(image, faces_detected)

    return len(faces)


while True:
    get_image_from_camera = get_image_from_camera(name="./test.jpg")
    count_faces = count_faces(image_path: str)
    time.sleep(10)
